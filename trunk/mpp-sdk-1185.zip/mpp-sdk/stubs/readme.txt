It is now recommended practice to compile your MIDlets against these jars.

The class stubs in these jars allow you to compile against CLDC and MIDP classes that contain J2ME-compliant class hierarchy (unlike the MPP jars which have compiled-in dependencies on J2SE classes).

Provided from the j2mepolish project.