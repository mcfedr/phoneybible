This version of preverify is built for OS X from the MIDP 2.0 Reference Implementation and distributed under the terms of the Sun SCSL.

To use preverify with mpowerplayer's cldc.jar and midp.jar implementations, you will also need to additionally specify your platform's classes.jar to allow preverify to find the bootstrap classes that are not included in our cldc library.

Therefore, typical usage under OS X will look something like this:

% ./preverify -classpath /System/Library/Frameworks/JavaVM.framework/Versions/CurrentJDK/Classes/classes.jar:~/mpp-sdk/cldc.jar:~/mpp-sdk/midp.jar build/*.class
 
NOTE: You will probably need to set the execute permission on the preverify executable (unless your de-archiver did it for you).

% chmod +x mpp-sdk/osx/preverify/preverify
