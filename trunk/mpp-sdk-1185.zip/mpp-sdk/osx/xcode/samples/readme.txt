These sample projects were built with the Xcode template.

HelloMobile: 
This is the simplest possible example.  This is what you get when you open and run a project from the Xcode template with no modifications.

MicroTank:
This is a Sun Microsystems' sample converted to build with Xcode.  It demonstrates how to use MIDP 2.0's Game API.

NOTE: You will probably need to set the execute permission on the preverify executable (unless your de-archiver did it for you).

% chmod +x mpp-sdk/osx/preverify/preverify

