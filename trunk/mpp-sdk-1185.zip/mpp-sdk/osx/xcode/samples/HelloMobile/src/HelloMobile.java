
import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;

public class HelloMobile extends MIDlet implements CommandListener
{
    private Display mDisplay;
    private Command exitCmd;
    private Form mForm;
	
    public void startApp()
    {
		if ( mForm == null )
		{
			mForm = new Form( "Welcome to a MIDlet!" );
			exitCmd = new Command( "Exit", Command.EXIT, 0 );
			mForm.addCommand( exitCmd );
			mForm.setCommandListener( this );
			mDisplay = Display.getDisplay( this );
		}
		
		mDisplay.setCurrent( mForm );
	}
	
    public void pauseApp()
    {
    }
	
	
    public void destroyApp( boolean unconditional )
    {
    }
	
	public void commandAction( Command c, Displayable s )
    {   
        if ( c == exitCmd )
        {
            destroyApp( true );
            notifyDestroyed();
        }
	}
}
