This Xcode template was graciously provided by haikusw.

The online version of this document can be found at:
http://haikusoftware.com/midletdev/xcodemidlets.html

questions or suggestions:
http://developer.mpowerplayer.com

howto:

uncompress the template archive

put the "Ant-based MIDlet Jar" folder into:
/Library/Application Support/Apple/Developer Tools/Project Templates/Java/ 
or one of the other folders inside the "Project Templates" folder.

create a symbolic link to the mpp-sdk folder into /Developer/Java:
ln -s  /foo/mypath/to/where/i/put/mpp-sdk mpp-sdk 

from Xcode, select "File -> New Project" and then choose "Ant-based MIDlet JAR" from the list of templates. You will have a project that you can build and run in the emulator to start from.

NOTE: You will probably need to set the execute permission on the preverify executable (unless your de-archiver did it for you).

% chmod +x mpp-sdk/osx/preverify/preverify


