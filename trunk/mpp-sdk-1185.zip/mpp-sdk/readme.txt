* Quick Start *

To run mpowerplayer from the command line:
   java -jar player.jar 

Load your midlet by opening a .jad or .jar file:
 - Open over the network with File-Open URL
 - Open from the file system with File-Open
 - Drag and drop to the player window
 - As a command line parameter, example: "java -jar player.jar /MyProjects/Demos/Demo1.jad"

To debug midlets from your preferred debugging tool:
 - Add player.jar, contained in the mpp-sdk directory, to your debugger's classpath.
 - Make sure that the other jar files from the mpp-sdk are in your tool's default 'application home' directory. These are loaded at runtime by the player.
 - Have your debugger call the main method on the class com.mpp.player.PowerPlayerApp and pass any of your MIDlet's jad or jar files as command line arguments.

* About *

mpowerplayer is a MIDP 2.0 runtime written in pure Java.

Think of it as an appletviewer for midlets. If you know why that's useful, then this tool is for you.

With mpowerplayer, you can run J2ME applications on your desktop computer.  If you like, you can play the same games that run on your phone on your desktop.

Mobile application developers can develop and test their applications with little fuss. mpowerplayer integrates easily into developer build tools and IDEs. You can use your familiar J2SE debugger tools on your MIDP apps.

Even better, you can now use the mpowerplayer service to demonstrate your own applications directly from your website.  

See http://content.mpowerplayer.com for more information.

* Support *

Please direct all questions, comments, and bug reports to the developer forums:

http://developer.mpowerplayer.com

* FAQ *

What is this good for?

CLDC and CDC are subsets of the J2SE standard, but there are very few implementations of MIDP that can run on J2SE, and none of those implement MIDP 2.0 (much less any of the extensions like MMAPI).

What's more, this is the only MIDP 2.0 environment currently available for Mac OS X.

I'm new to MIDP.  Can you recommend a good book?

Everything we learned about MIDP came from "Wireless Java: Developing with J2ME": http://www.amazon.com/exec/obidos/ASIN/1590590775/mpowersllc-20

What properties can I set in the jad file?

These are some of the more common mpowerplayer-specific properties can be in either the jad file or in the manifest:

MPP-Width: Sets the initial width of the midlet content area.  The default is subject to change.
MPP-Height: Sets the initial height of the midlet content area.  The default is subject to change.
MPP-Resize: Sets whether the midlet is allowed to resize.  Depending on the MicroEdition-Profile property, this property defaults to "false" for MIDP 1.x and "true" for MIDP 2.x. 
MPP-FPS-Cap: Since our repaint loop is faster than many devices, this property regulates the number of times the screen is able to repaint itself.  Default is no capping.  
MPP-Scale: Specifies a scaling factor to apply to the midlet.  The default is "2.0".
MPP-Antialias: Controls whether antialiasing is used to for primitive drawing commands (lines and fonts).  Default is "true".
MPP-Invert-Keypad: Inverts the keypad keys so 7, 8, and 9 map to 1, 2, and 3, and vice versa.  Default is "false".
MPP-Font-Monospace: Replaces the platform's standard monospace font with the font you specify in standard java notation, e.g. "FontName-12".  MPP automatically maps the large size as 150% and the small size as 75% of what you specify.
MPP-Font-Proportional: Replaces the platform's standard proportional font with the font you specify in standard java notation, e.g. "FontName-12".  MPP automatically maps the large size as 150% and the small size as 75% of what you specify.

The full list is at http://mpowerplayer.com/sdk-properties.php

How do I get Bluetooth support?

Obtain the "AvetanaBluetooth.jar" file from http://www.avetana-gmbh.de/avetana-gmbh/produkte/jsr82.eng.xml.  It's 25 Euro for OS X and Windows, or free if you're on Linux.  Put the jar in the same directory you have the rest of the supporting jars (midp.jar, cldc.jar, etc.).  Make sure it's called "AvetanaBluetooth.jar" -- case sensitivity matters.

Is this open source?

While the contents of the cldc jar file is distributed under the LGPL, the MIDP implementation is proprietary. Unjar the cldc jar to obtain the source code.

What are your pricing plans?

The mpowerplayer sdk is and will continue to be a free download. 
