import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;

public class FirstPowerMIDlet
    extends MIDlet implements CommandListener {
  private Display mDisplay;
  private Form mForm;
  
  public void startApp() {
    if (mForm == null) {
      mForm = new Form("Welcome to mpowerplayer!");
      Command exitCommand = new Command("Exit", Command.EXIT, 0);
      mForm.addCommand(exitCommand);
      mForm.setCommandListener(this);
      mDisplay = Display.getDisplay(this);
    }
    mDisplay.setCurrent(mForm);
  }
  
  public void pauseApp() {}
  
  public void destroyApp(boolean unconditional) {}
  
  public void commandAction(Command c, Displayable s) {
    if (c.getCommandType() == Command.EXIT) {
      destroyApp(true);
      notifyDestroyed();
    }
  }
}
