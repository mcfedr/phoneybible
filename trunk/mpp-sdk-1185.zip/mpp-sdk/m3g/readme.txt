JSR-184 Mobile 3D Graphics (M3G) support:

Put m3g.jar and the two platform-specific support jars in the same directory you have the rest of the supporting jars (midp.jar, cldc.jar, etc.). 

Notes:
 - we have some problems with alpha blending and background blending, but everything else seems to be working great!
 - we're leveraging lwjgl for hardware 3d support.  we are especially interested in cases where lwjgl demos work but our m3g doesn't.  
 - please direct support issues and bug reports to the developer forum at http://developer.mpowerplayer.com.
 - please PLEASE be sure to include your operating system and video card manufacturer and driver version in your problem reports.
 - all classes and methods are implemented.  if not, please let us know what's not working on the forums.
