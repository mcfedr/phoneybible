This is very experimental Mobile 2D Graphics (M2G) (JSR 226) support built on top of Apache Batik and Xerces.  It's not fully compliant, but it's enough to get you going, particularly if you stick programmatic usage of ScalableImages and ScalableGraphics.

To install, move m2d.jar and xerces.jar into the same directory as player.jar.  Then launch the mpowerplayer and you're good to go.