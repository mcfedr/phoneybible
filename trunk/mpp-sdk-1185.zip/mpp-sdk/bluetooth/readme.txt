Bluetooth support:

Our limited promotional license to distribute the bluetooth library expired on 31 March 2006.

However, it is still available from the original vendor at:

http://www.avetana-gmbh.de/avetana-gmbh/produkte/jsr82.eng.xml

It's cheap and good so please show Avetana your support.  Thanks!