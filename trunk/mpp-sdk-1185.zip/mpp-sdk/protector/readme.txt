The mpp protector takes jad and jar files and combines them into a single 
encrypted file.  Use this to protect your content before making it available for demonstration with the mpowerplayer webstart service.  The protector accepts both file paths and network urls as arguments.

Usage:
java -jar protector.jar [-out output-dir] [-force] path-to-jad-or-jar ...

Example:
mpp% java -jar protector.jar http://ota.mpowers.net/piranha/pna-us.jad
mpp protector 1.0.373
 read: http://ota.mpowers.net/piranha/pna-us.jar
wrote: Piranha Pricecheck.mpz
SHA-1: 8314443f3565eb1b56e07cb02d8f333fbfa0cbda

The generated mpz file cannot be opened by the mpp-sdk.  You will need to setup a link to the mpowerplayer webstart service from a page on your web server.  See http://content.mpowerplayer.com for full details.

The mpp protector not only encrypts your files, it also injects both j2se-specific and mpp-specific bytecodes into the encrypted classfiles, making them unusable outside the mpowerplayer environment.  For improved desktop performance, calls to System.gc are removed.  For compatibility with mpp's classloader scheme, calls to getResourceAsStream on system or bootstrap classes are redirected to your midlet class.